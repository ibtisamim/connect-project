<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Support;
use App\Models\Supportdetails;
use Illuminate\Http\Request;

class SupportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $supports = Supportdetails::where('lang','en')->get();

       return view('admin.pages.support.index',compact('supports'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      return view('admin.pages.support.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->validate([
          'question_en'=>'required',
          'answer_en'=>'required',
          'question_ar'=>'required',
          'answer_ar'=>'required',
        ]);

        $support = Support::create([
          'order'=>0,
        ]);


        Supportdetails::create([
          'question'=>$data['question_en'],
          'answer'=>$data['answer_en'],
          'lang'=>'en',
          'support_id'=>$support->id,
        ]);

        Supportdetails::create([
          'question'=>$data['question_ar'],
          'answer'=>$data['answer_ar'],
          'lang'=>'ar',
          'support_id'=>$support->id,
        ]);

        return redirect()->route('support.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $support = Supportdetails::where('support_id',$id)->get();

      return view('admin.pages.support.edit',compact('support'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,Support $support)
    {


      $data = $request->validate([
        'question_en'=>'required',
        'answer_en'=>'required',
        'question_ar'=>'required',
        'answer_ar'=>'required',
      ]);

      Supportdetails::where('support_id',$support->id)->where('lang','en')->update([
          'question'=>$data['question_en'],
          'answer'=>$data['answer_en'],
      ]);

      Supportdetails::where('support_id',$support->id)->where('lang','ar')->update([
        'question'=>$data['question_ar'],
        'answer'=>$data['answer_ar'],
      ]);

      return redirect()->route('support.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Support $support)
    {
        $support->delete();
        return redirect()->route('support.index');
    }
}
