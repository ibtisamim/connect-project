<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserDbSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Testing\Fluent\Concerns\Has;

class UserDbSettingController extends Controller
{

    public function index()
    {

     $user_data = UserDbSetting::with('media')->where('user_id', Auth::user()->id)->first();


      return view('user.user_db_setting' ,compact('user_data',$user_data));

    }

    public function create()
    {

    }

    public function store(Request $request)
    {

    }

    public function show($id)
    {

    }

    public function edit($id)
    {

    }

    public function update(Request $request,$user_id)
    {



     $user_db = UserDbSetting::where('user_id',$user_id)->first();

     $data = $request->validate([
       'name' => 'nullable',
       'job'  => 'nullable',
       'bio'  =>'nullable',
       'contry' => 'nullable',
       'area'=>'nullable',
       'city'=>'nullable',
       'street' =>'nullable',
       'facebook' =>'nullable',
       'instagram' =>'nullable',
       'twiter'=>'nullable',
       'youtube'=>'nullable',
       'linkedin'=>'nullable',
       'tiktok'=>'nullable',
       'image'=>'nullable',

     ]);



      UserDbSetting::where('user_id',$user_id)->update([
        'name' => $data['name'],
        'job_description'   =>$data['job'],
        'bio'               => $data['bio'],
        'contry'            => $data['contry'],
        'area'              =>$data['area'],
        'city'              =>$data['city'],
        'street'            =>$data['street'],
        'facebook'          =>$data['facebook'],
        'instagrm'          =>$data['instagram'],
        'twiter'            =>$data['twiter'],
        'youtube'           =>$data['youtube'],
        'linkedin'          =>$data['linkedin'],
        'tiktok'            =>$data['tiktok'],
      ]);


      if($request->image_user){

        $user_db->addMedia($request->image_user)->toMediaCollection('images');
      }

      $user =  User::where('id',$user_id)->first();
      if(Hash::check($request->current_paseword , $user->password)){
        if($request->new_password == $request->confirm){
          $user->update([
            'password'=>Hash::make($request->new_password),
          ]);
        }
      }




      return redirect()->route('user_setting.index');
    }

    public function destroy($id)
    {

    }

}
