<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\MemberDescription;
use App\Models\Member;

class memberController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $members =  MemberDescription::select('id','member_id','name')->where('lang','en')->get();

         return view('admin.pages.member.index',compact('members'));
    }


    public function create()
    {
        return view('admin.pages.member.create');
    }


    public function store(Request $request)
    {
       $data = $request->validate([
           'name_ar'=>'required',
           'name_en'=>'required',
       ]);


        $slug  = $this->slug($request->name_en);

        $memebr =   Member::create([
            'slug'=>$slug,
        ]);

        MemberDescription::create([
            'name'=>$data['name_ar'],
            'lang'=>'ar',
            'member_id'=>$memebr->id,
        ]);

        MemberDescription::create([
            'name'=>$data['name_en'],
            'lang'=>'en',
            'member_id'=>$memebr->id,
        ]);


        return redirect()->route('members.index');


    }


    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        $member =  MemberDescription::where('member_id',$id)->get();

       return view('admin.pages.member.edit',compact('member'));

    }


    public function update(Request $request, $id)
    {
        $data = $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',
        ]);


        $slug  = $this->slug($request->name_en);

        Member::where('id',$id)->update([
            'slug'=>$slug,
        ]);

        MemberDescription::where('member_id',$id)->where('lang','ar')->update([
            'name'=>$data['name_ar'],
        ]);

        MemberDescription::where('member_id',$id)->where('lang','en')->update([
            'name'=>$data['name_en'],
        ]);


        return redirect()->route('members.index');
    }


    public function destroy($id)
    {
        $member = Member::find($id);

        $member->delete();

        return redirect()->route('members.index');
    }

    private function slug($str, $limit = null) {
        if ($limit) {
            $str = mb_substr($str, 0, $limit, "utf-8");
        }
        $text = html_entity_decode($str, ENT_QUOTES, 'UTF-8');
        // replace non letter or digits by -
        $text = preg_replace('~[^\\pL\d]+~u', '-', $text);
        // trim
        $text = trim($text, '-');
        return $text;
    }
}
