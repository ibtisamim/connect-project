<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ProjectCategory;
use Illuminate\Http\Request;

class ProjectCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $project_categories = ProjectCategory::all();
       return view('admin.pages.project-categories.index',compact('project_categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.pages.project-categories.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->validate([
          'title_en'=>'required',
          'title_ar'=>'required',
        ]);

        ProjectCategory::create([
          'title_en'=>$data['title_en'],
          'title_ar'=>$data['title_ar'],
        ]);

        return redirect()->route('project_categories.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       $projectCategory =  ProjectCategory::where('id',$id)->first();
       return view('admin.pages.project-categories.edit',compact('projectCategory'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProjectCategory $projectCategory)
    {

      $data = $request->validate([
        'title_en'=>'required',
        'title_ar'=>'required',
      ]);

      $projectCategory->update([
        'title_en'=>$data['title_en'],
        'title_ar'=>$data['title_ar']
      ]);

      return redirect()->route('project_categories.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProjectCategory $projectCategory)
    {
      $projectCategory->delete();
      return redirect()->route('project_categories.index');
    }
}
