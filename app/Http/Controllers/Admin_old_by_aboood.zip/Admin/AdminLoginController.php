<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class AdminLoginController extends Controller
{
   public function view_login(){
     return view('auth.login_admin');
   }
   public function login(Request $request)
   {

        $data = $request->validate([
            'name' => 'required',
            'password' => 'required|min:6'
        ]);

     if (Auth::guard('admin')->attempt(['name' => $data['name'], 'password' => $data['password'] ])) {

         $admin = Admin::with('media')->where('id',Auth::guard('admin')->user()->id)->first();

         return redirect()->route('dashboard',compact('admin'));

     }

     return redirect()->route('view_login');
   }

}
