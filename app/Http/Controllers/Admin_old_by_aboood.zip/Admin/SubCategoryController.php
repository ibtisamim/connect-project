<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\CategoryDescription;
use App\Models\SubCategory;
use App\Models\SubCategoryDescription;
use Illuminate\Http\Request;

class SubCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $sub_categories =  SubCategory::with('subCategoryDescription','media')->get();

      return view('admin.pages.sub-categories.index',compact('sub_categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         $all_category = CategoryDescription::select('category_id','title')->where('lang','en')->get();

       return view('admin.pages.sub-categories.create',compact('all_category'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {



      function slug($str, $limit = null) {
        if ($limit) {
          $str = mb_substr($str, 0, $limit, "utf-8");
        }
        $text = html_entity_decode($str, ENT_QUOTES, 'UTF-8');
        // replace non letter or digits by -
        $text = preg_replace('~[^\\pL\d]+~u', '-', $text);
        // trim
        $text = trim($text, '-');
        return $text;
      }

      $slug_ar  = slug($request->title_ar);
      $slug_en  = slug($request->title_en);



      $data = $request->validate([
        'title_ar'=>'required',
        'description_ar'=>'required',
        'title_en'=>'required',
        'description_en'=>'required',
        'category_id'=>'required',
      ]);

      $sub_category = SubCategory::create([
          'category_id'=>$data['category_id'],
      ]);


      SubCategoryDescription::create([
        'title' =>$data['title_en'],
        'description' =>$data['description_en'],
        'lang'=>'en',
        'slug'=>$slug_en,
        'sub_category_id'=>$sub_category->id
      ]);

      SubCategoryDescription::create([
        'title' =>$data['title_ar'],
        'description' =>$data['description_ar'],
        'lang'=>'ar',
        'slug'=>$slug_ar,
        'sub_category_id'=>$sub_category->id
      ]);

      $sub_category->addMedia($request->image_sub_category)->toMediaCollection('images');

      return redirect()->route('sub_categories.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(SubCategory $subCategory)
    {

        $all_category = CategoryDescription::select('category_id','title')->where('lang','en')->get();

        $select_category =   SubCategory::select('id','category_id')->where('id',$subCategory->id)->first();

        $sub_category = SubCategoryDescription::where('sub_category_id',$subCategory->id)->get();

        $category_image = SubCategory::with('media')->where('id',$subCategory->id)->first();

        return view('admin.pages.sub-categories.edit',compact('sub_category','all_category','select_category','category_image'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SubCategory $subCategory)
    {

      $slug_ar  = $this->slug($request->title_ar);
      $slug_en  = $this->slug($request->title_en);

      $data = $request->validate([
        'title_ar'=>'required',
        'description_ar'=>'required',
        'title_en'=>'required',
        'description_en'=>'required',
        'category_id'=>'required',
      ]);

      if($request->image_sub_category){
        $subCategory->addMedia($request->image_sub_category)->toMediaCollection('images');
      }

       SubCategory::where('id',$subCategory->id)->update([
          'category_id'=>$data['category_id'],
      ]);

      SubCategoryDescription::where('sub_category_id',$subCategory->id)->where('lang','en')->update([
        'title' =>$data['title_en'],
        'description' =>$data['description_en'],
        'slug'=>$slug_en,
      ]);

      SubCategoryDescription::where('sub_category_id',$subCategory->id)->where('lang','ar')->update([
        'title' =>$data['title_ar'],
        'description' =>$data['description_ar'],
        'slug'=>$slug_ar,
      ]);



      return redirect()->route('sub_categories.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(SubCategory $subCategory)
    {
        $subCategory->delete();

        return redirect()->route('sub_categories.index');
    }


    private function slug($str, $limit = null) {
      if ($limit) {
        $str = mb_substr($str, 0, $limit, "utf-8");
      }
      $text = html_entity_decode($str, ENT_QUOTES, 'UTF-8');
      // replace non letter or digits by -
      $text = preg_replace('~[^\\pL\d]+~u', '-', $text);
      // trim
      $text = trim($text, '-');
      return $text;
    }

}
