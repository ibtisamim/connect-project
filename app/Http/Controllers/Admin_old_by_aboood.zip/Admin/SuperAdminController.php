<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use App\Models\SuperAdmin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class SuperAdminController extends Controller
{


  public function profile( $id){
     $profile = Admin::with('media')->where('id',$id)->first();

     return view('admin.pages.admins.edit-profile',compact('profile'));
  }

  public function update_profile(Request $request , $id){
      $admin =  Admin::where('id',$id)->first();

    $data = $request->validate([
      'name'=>'required',
    ]);

    $admin->update([
      'name'=>$data['name'],
      'password'=>Hash::make($request->password),
    ]);

    if($request->hasFile('image')){
      $admin->addMedia($request->image)->toMediaCollection('images');
    }
    return redirect()->route('dashboard');
  }

}
