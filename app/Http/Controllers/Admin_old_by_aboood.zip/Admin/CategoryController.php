<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\CategoryDescription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use App\Models\MemberDescription;
use App\Models\CategoryMember;
class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $categories =  Category::with('categoryDescription','media')->get();

        return view('admin.pages.categories.index',compact('categories'));
    }


    public function create()
    {
       $members =  MemberDescription::select('name','id','member_id')->where('lang','en')->get();
        return view('admin.pages.categories.create',compact('members'));
    }


    public function store(Request $request)
    {


      function slug($str, $limit = null) {
        if ($limit) {
          $str = mb_substr($str, 0, $limit, "utf-8");
        }
        $text = html_entity_decode($str, ENT_QUOTES, 'UTF-8');
        // replace non letter or digits by -
        $text = preg_replace('~[^\\pL\d]+~u', '-', $text);
        // trim
        $text = trim($text, '-');
        return $text;
      }

      $slug_ar  = slug($request->title_ar);
      $slug_en  = slug($request->title_en);

      $data = $request->validate([
        'title_ar'=>'required',
        'description_ar'=>'required',
        'title_en'=>'required',
        'description_en'=>'required',
      ]);

      $category = Category::create();


      CategoryDescription::create([
        'title' =>$data['title_en'],
        'description' =>$data['description_en'],
        'lang'=>'en',
        'slug'=>$slug_en,
        'category_id'=>$category->id,
      ]);

      CategoryDescription::create([
        'title' =>$data['title_ar'],
        'description' =>$data['description_ar'],
        'lang'=>'ar',
        'slug'=>$slug_ar,
        'category_id'=>$category->id,
      ]);

      foreach($request->members as $key => $member){
          CategoryMember::create([
              'category_id'=>$category->id,
              'member_id'=>$member,
          ]);
      }

      $category->addMedia($request->image_category)->toMediaCollection('images');

      return redirect()->route('categories.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Category $category)
    {

        $category =   Category::with('categoryDescription','member','media')->where('id',$category->id)->first();

        $all_member =  MemberDescription::select('name','id','member_id')->where('lang','en')->get();
        return view('admin.pages.categories.edit',compact('category','all_member'));
    }


    public function update(Request $request,Category $category)
    {



      $slug_ar  = $this->slug($request->title_ar);
      $slug_en  = $this->slug($request->title_en);

      $data = $request->validate([
        'title_ar'=>'required',
        'description_ar'=>'required',
        'title_en'=>'required',
        'description_en'=>'required',

      ]);


      if($request->image_category){
        $category->addMedia($request->image_category)->toMediaCollection('images');
      }


      CategoryDescription::where('category_id',$category->id)->where('lang','en')->update([
        'title' =>$data['title_en'],
        'description' =>$data['description_en'],
        'slug'=>$slug_en,

      ]);


      CategoryDescription::where('category_id',$category->id)->where('lang','ar')->update([
        'title' =>$data['title_ar'],
        'description' =>$data['description_ar'],
        'slug'=>$slug_ar,

      ]);

        $all_member = CategoryMember::where('category_id',$category->id)->get();

        foreach($all_member as $member){
            $member->delete();
        }

        foreach($request->members as $key => $member){
            CategoryMember::create([
                'category_id'=>$category->id,
                'member_id'=>$member,
            ]);
        }

      return redirect()->route('categories.index');
    }


    public function destroy($id)
    {
        //
    }

    private function slug($str, $limit = null) {
      if ($limit) {
        $str = mb_substr($str, 0, $limit, "utf-8");
      }
      $text = html_entity_decode($str, ENT_QUOTES, 'UTF-8');
      // replace non letter or digits by -
      $text = preg_replace('~[^\\pL\d]+~u', '-', $text);
      // trim
      $text = trim($text, '-');
      return $text;
    }
}
